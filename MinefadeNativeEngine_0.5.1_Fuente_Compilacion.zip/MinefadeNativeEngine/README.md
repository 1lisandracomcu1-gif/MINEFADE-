# Minefade Native Engine 0.5.1

Minefade's independent native Android engine project. The application target is Java 17 + JNI + C++20, rendered through OpenGL ES 3, with RmlUi 6.3 for the in-game interface.

## Implemented project layers

- Android Activity and `GLSurfaceView` host with JNI bridge.
- C++ engine lifecycle, OpenGL ES 3 world renderer, atlas upload, day/night lighting, and touch input.
- RmlUi 6.3 runtime and custom OpenGL ES render interface.
- Voxel chunks, deterministic terrain generation, block meshing, transparent pass, player movement/collision, inventory, basic entities, and local save/load.
- 284-entry block registry/catalogue, per-face texture atlas, break/place/drop metadata, and validation tests.
- Local sound feedback for block break/place and UI clicks.

## Build

Read [docs/APK_BUILD_STATUS.md](docs/APK_BUILD_STATUS.md) for the exact pinned requirements and verification status. With Android SDK platform 36, Build Tools 36.0.0, NDK 28.2.13676358, CMake 3.22.1, JDK 17+, Gradle 9.6.0 and internet access for the pinned native dependencies, run:

```sh
./build-debug.sh
```

The APK is only considered ready after Gradle creates it and the build script verifies its signature and package metadata. This project has **not** yet been built, installed, or launched on an Android device in the current environment.

## Tests available here

```sh
./tests/run-world-tests.sh
```

These tests validate CPU-side world/catalogue logic. They do not replace an NDK build or Android-device test.

## Key source paths

- `app/src/main/cpp/NativeEngine.cpp` — JNI bridge.
- `app/src/main/cpp/engine/` — native engine and render loop.
- `app/src/main/cpp/world/` — chunk and voxel world.
- `app/src/main/cpp/blocks/` — block registry.
- `app/src/main/cpp/game/` — player, inventory, entities.
- `app/src/main/cpp/ui/` — RmlUi runtime and OpenGL ES backend.
- `app/src/main/java/` — Android host and touch/audio bridge.
- `app/src/main/assets/` — block definitions, Minefade catalog, texture atlas, and sound effects.


## APK status (latest attempt)

The APK has **not** been built in this workspace. The build container has no Android SDK/NDK/Build Tools or Gradle installation, and DNS resolution fails for `services.gradle.org` and `dl.google.com`. See [docs/APK_BUILD_STATUS.md](docs/APK_BUILD_STATUS.md) and [docs/BUILD_APK_LOCAL.md](docs/BUILD_APK_LOCAL.md) for the exact diagnostics and local build steps. The world smoke tests and block-catalogue validation pass. The atlas reserves 864 tiles; 852 are referenced by the current block definitions.
