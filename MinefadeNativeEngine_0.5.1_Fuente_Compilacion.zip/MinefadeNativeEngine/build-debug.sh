#!/usr/bin/env sh
# Reproducible local Android debug build with preflight and APK verification.
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK_ROOT" ] || [ ! -d "$SDK_ROOT" ]; then
    echo "ERROR: Android SDK is missing. Set ANDROID_HOME or ANDROID_SDK_ROOT to its SDK directory." >&2
    exit 2
fi

JAVA_BIN="$(command -v java || true)"
if [ -z "$JAVA_BIN" ]; then
    echo "ERROR: Java 17+ is required to run the Android Gradle Plugin." >&2
    exit 2
fi

COMPILE_SDK="$SDK_ROOT/platforms/android-36/android.jar"
BUILD_TOOLS="$SDK_ROOT/build-tools/36.0.0"
NDK_DIR="$SDK_ROOT/ndk/28.2.13676358"
CMAKE_DIR="$SDK_ROOT/cmake/3.22.1"

[ -s "$COMPILE_SDK" ] || { echo "ERROR: Missing Android API 36 platform: $COMPILE_SDK" >&2; exit 2; }
[ -x "$BUILD_TOOLS/aapt2" ] || { echo "ERROR: Missing Android Build Tools 36.0.0 (aapt2) in $BUILD_TOOLS" >&2; exit 2; }
[ -x "$BUILD_TOOLS/apksigner" ] || { echo "ERROR: Missing apksigner in $BUILD_TOOLS" >&2; exit 2; }
[ -s "$NDK_DIR/source.properties" ] || { echo "ERROR: Missing Android NDK 28.2.13676358 in $NDK_DIR" >&2; exit 2; }
[ -x "$CMAKE_DIR/bin/cmake" ] || { echo "ERROR: Missing Android CMake 3.22.1 in $CMAKE_DIR" >&2; exit 2; }

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_NDK_HOME="$NDK_DIR"
export ANDROID_NDK_ROOT="$NDK_DIR"

printf '%s\n' '== Minefade native logic and block catalogue tests =='
./tests/run-world-tests.sh

printf '%s\n' '== Android debug build (C++20 + OpenGL ES 3 + RmlUi 6.3) =='
./gradlew --no-daemon --stacktrace :app:assembleDebug

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[ -s "$APK" ] || { echo "ERROR: Gradle finished without producing $APK" >&2; exit 3; }

"$BUILD_TOOLS/apksigner" verify --verbose "$APK"
"$BUILD_TOOLS/aapt2" dump badging "$APK" | sed -n '1,18p'

printf '\nAPK ready and signature-verified: %s\n' "$APK"
if [ "${INSTALL_ON_DEVICE:-0}" = "1" ]; then
    command -v adb >/dev/null 2>&1 || { echo "ERROR: INSTALL_ON_DEVICE=1 but adb is unavailable." >&2; exit 4; }
    adb install -r "$APK"
fi
