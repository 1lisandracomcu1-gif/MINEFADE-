# Minefade Native Engine 0.5.1 — APK build status

## Result of the latest build attempt

**No APK was produced in this environment.** The build was attempted and stopped before Gradle could configure the Android project because this container has no Android SDK, NDK, Android Build Tools, or installed Gradle.

Observed errors:

- `./build-debug.sh`: `ERROR: Android SDK is missing. Set ANDROID_HOME or ANDROID_SDK_ROOT to its SDK directory.`
- `./gradlew --version`: the Gradle bootstrapper attempted to download Gradle 9.6.0, but curl failed with `Could not resolve host: services.gradle.org` (three retries).
- Direct connectivity check for Google's Android command-line tools failed with `Could not resolve host: dl.google.com`.
- No APK exists under `app/build/outputs/`.

## Checks that did pass

- `./tests/run-world-tests.sh` passed the voxel-world smoke tests.
- The block-catalogue test passed: 284 block definitions, 852 distinct referenced face tiles, and 1,119,744 bytes of RGBA atlas data.
- The atlas reserves 864 tile slots; 852 of those slots are currently referenced by block definitions.
- A prior host syntax-only check passed for the seven application C++ translation units using RmlUi 6.3 headers and declaration-only Android/GLES stubs. This is not an Android NDK compile or link.
- A prior Java 17 syntax check passed against minimal Android API stubs. This is not a build against the real Android SDK.
- Android manifest and resource XML passed parsing.

## Pinned Android build configuration

- Android Gradle Plugin: 9.5.0
- Gradle: 9.6.0
- JDK: 17 or newer (AGP compatibility target is JDK 17)
- Compile SDK: 36
- Build Tools: 36.0.0
- Android NDK: 28.2.13676358
- Android CMake: 3.22.1
- Native ABI filters: `arm64-v8a`, `armeabi-v7a`
- C++: C++20
- Renderer: OpenGL ES 3
- UI: RmlUi 6.3
- Font engine: FreeType 2.13.3

## How to produce the APK on a machine with Android Studio

1. Install Android Studio and its Android SDK.
2. In SDK Manager, install Android SDK Platform 36, Android SDK Build-Tools 36.0.0, NDK (Side by side) 28.2.13676358, and CMake 3.22.1.
3. Install/select JDK 17 or newer for Gradle.
4. Open this project folder (`MinefadeNativeEngine`) in Android Studio and allow Gradle sync to finish. The first native build needs network access to fetch the pinned RmlUi and FreeType source repositories.
5. Run the `:app:assembleDebug` Gradle task or, from a terminal with `ANDROID_HOME` set, run `./build-debug.sh` (Windows users can use Android Studio's Gradle task runner).
6. After a successful build, verify and test `app/build/outputs/apk/debug/app-debug.apk` on a physical Android device. The current build script verifies APK signature and package metadata when the required Build Tools are installed.

## Release criteria

Do not mark the native engine as delivered until all of these checks pass:

- CMake configures with the actual Android NDK and fetches/compiles RmlUi and FreeType.
- `libminefade_native.so` links for `arm64-v8a` (and `armeabi-v7a` if retained).
- Gradle creates a non-empty APK.
- `apksigner verify` succeeds and package metadata identifies `com.minefade.nativeengine`.
- The APK installs and launches on a physical Android device.
- A 3D voxel scene renders and touch input works without a white screen or crash.

Until then, there is no verified installable APK to provide.
