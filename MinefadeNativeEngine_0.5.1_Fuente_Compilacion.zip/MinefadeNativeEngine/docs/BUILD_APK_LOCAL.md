# Build Minefade Native Engine APK locally

## Required tools

- Android Studio with JDK 17 or newer
- Android SDK Platform 36
- Android SDK Build-Tools 36.0.0
- Android NDK 28.2.13676358 (Side by side)
- Android CMake 3.22.1
- Network access to `services.gradle.org`, `dl.google.com`, `github.com`, and Maven/Google plugin repositories for first-time dependency downloads

## Android Studio

1. Extract/open the `MinefadeNativeEngine` project directory.
2. In **Tools → SDK Manager → SDK Tools**, enable **Show Package Details**.
3. Install NDK `28.2.13676358` and CMake `3.22.1`.
4. In **SDK Platforms**, install Android API 36.
5. Set Gradle JDK to JDK 17 or newer.
6. Sync the project, then run Gradle task `:app:assembleDebug`.
7. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Linux/macOS terminal

```sh
export ANDROID_HOME="$HOME/Android/Sdk" # change this to your SDK path
export ANDROID_SDK_ROOT="$ANDROID_HOME"
./build-debug.sh
```

`build-debug.sh` runs the native logic/catalogue tests, checks required SDK components, runs the Gradle build, and verifies the generated APK signature and package metadata. It exits with an error rather than pretending a missing APK exists.

## Windows

Open the project in Android Studio and run `:app:assembleDebug`. The included `gradlew.bat` bootstraps the pinned Gradle distribution, but the first run needs Internet access and the Android SDK/NDK/CMake components above.

## Important

This project has not yet been proven to compile or run on a physical Android device. After producing the APK, install and test it on the target phone before treating it as a release build.
