#include "Engine.h"

#include <android/log.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <string>
#include <utility>

namespace minefade {
namespace {
constexpr const char* kTag = "MinefadeNative";
constexpr float kPi = 3.14159265358979323846f;
#define ENGINE_LOGI(...) __android_log_print(ANDROID_LOG_INFO, kTag, __VA_ARGS__)
#define ENGINE_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, kTag, __VA_ARGS__)

constexpr char kWorldVertexShader[] = R"(
#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec3 aColor;
layout(location=3) in vec2 aTexCoord;
uniform mat4 uMvp;
uniform vec3 uLightDirection;
uniform float uDaylight;
out mediump vec3 vColor;
out mediump vec2 vTexCoord;
void main() {
    gl_Position = uMvp * vec4(aPosition, 1.0);
    float diffuse = max(dot(normalize(aNormal), normalize(-uLightDirection)), 0.0);
    float ambient = mix(0.22, 0.38, uDaylight);
    float illumination = ambient + diffuse * (0.42 + 0.58 * uDaylight);
    vColor = aColor * illumination;
    vTexCoord = aTexCoord;
}
)";

constexpr char kWorldFragmentShader[] = R"(
#version 300 es
precision mediump float;
in mediump vec3 vColor;
in mediump vec2 vTexCoord;
uniform sampler2D uBlockAtlas;
uniform int uUseAtlas;
out vec4 outColor;
void main() {
    vec4 texel = (uUseAtlas == 1) ? texture(uBlockAtlas, vTexCoord) : vec4(1.0);
    outColor = vec4(texel.rgb * vColor, texel.a);
}
)";

Vec3 Add(const Vec3& a, const Vec3& b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }

} // namespace

Engine& GetEngine() {
    static Engine engine;
    return engine;
}

Engine::Mat4 Engine::Perspective(float fovRadians, float aspect, float nearPlane, float farPlane) {
    const float safeAspect = std::max(aspect, 0.001f);
    const float f = 1.0f / std::tan(fovRadians * 0.5f);
    Mat4 result{};
    result.v[0] = f / safeAspect;
    result.v[5] = f;
    result.v[10] = (farPlane + nearPlane) / (nearPlane - farPlane);
    result.v[11] = -1.0f;
    result.v[14] = (2.0f * farPlane * nearPlane) / (nearPlane - farPlane);
    return result;
}

Engine::Mat4 Engine::LookAt(const Vec3& eye, const Vec3& target, const Vec3& up) {
    const auto normalize = [](const Vec3& value) {
        const float length = std::sqrt(std::max(value.x * value.x + value.y * value.y + value.z * value.z, 0.000001f));
        return Vec3{value.x / length, value.y / length, value.z / length};
    };
    const auto cross = [](const Vec3& a, const Vec3& b) {
        return Vec3{a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
    };
    const auto dot = [](const Vec3& a, const Vec3& b) { return a.x*b.x + a.y*b.y + a.z*b.z; };
    const Vec3 forward = normalize({target.x - eye.x, target.y - eye.y, target.z - eye.z});
    const Vec3 side = normalize(cross(forward, up));
    const Vec3 correctedUp = cross(side, forward);
    Mat4 result{};
    result.v[0] = side.x; result.v[1] = correctedUp.x; result.v[2] = -forward.x; result.v[3] = 0.0f;
    result.v[4] = side.y; result.v[5] = correctedUp.y; result.v[6] = -forward.y; result.v[7] = 0.0f;
    result.v[8] = side.z; result.v[9] = correctedUp.z; result.v[10] = -forward.z; result.v[11] = 0.0f;
    result.v[12] = -dot(side, eye); result.v[13] = -dot(correctedUp, eye); result.v[14] = dot(forward, eye); result.v[15] = 1.0f;
    return result;
}

Engine::Mat4 Engine::Multiply(const Mat4& a, const Mat4& b) {
    Mat4 result{};
    for (int column = 0; column < 4; ++column) {
        for (int row = 0; row < 4; ++row) {
            float value = 0.0f;
            for (int k = 0; k < 4; ++k)
                value += a.v[static_cast<std::size_t>(k * 4 + row)] * b.v[static_cast<std::size_t>(column * 4 + k)];
            result.v[static_cast<std::size_t>(column * 4 + row)] = value;
        }
    }
    return result;
}

GLuint Engine::CompileShader(GLenum type, const char* source) {
    const GLuint shader = glCreateShader(type);
    if (shader == 0) return 0;
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint compiled = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    if (compiled != GL_TRUE) {
        GLint length = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &length);
        std::string log(static_cast<std::size_t>(std::max(length, 1)), '\0');
        glGetShaderInfoLog(shader, length, nullptr, log.data());
        ENGINE_LOGE("World shader failed: %s", log.c_str());
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

bool Engine::CreateWorldProgram() {
    const GLuint vertex = CompileShader(GL_VERTEX_SHADER, kWorldVertexShader);
    const GLuint fragment = CompileShader(GL_FRAGMENT_SHADER, kWorldFragmentShader);
    if (vertex == 0 || fragment == 0) {
        if (vertex != 0) glDeleteShader(vertex);
        if (fragment != 0) glDeleteShader(fragment);
        return false;
    }
    worldProgram_ = glCreateProgram();
    glAttachShader(worldProgram_, vertex);
    glAttachShader(worldProgram_, fragment);
    glLinkProgram(worldProgram_);
    glDeleteShader(vertex);
    glDeleteShader(fragment);

    GLint linked = GL_FALSE;
    glGetProgramiv(worldProgram_, GL_LINK_STATUS, &linked);
    if (linked != GL_TRUE) {
        GLint length = 0;
        glGetProgramiv(worldProgram_, GL_INFO_LOG_LENGTH, &length);
        std::string log(static_cast<std::size_t>(std::max(length, 1)), '\0');
        glGetProgramInfoLog(worldProgram_, length, nullptr, log.data());
        ENGINE_LOGE("World program failed: %s", log.c_str());
        glDeleteProgram(worldProgram_);
        worldProgram_ = 0;
        return false;
    }
    mvpLocation_ = glGetUniformLocation(worldProgram_, "uMvp");
    lightLocation_ = glGetUniformLocation(worldProgram_, "uLightDirection");
    daylightLocation_ = glGetUniformLocation(worldProgram_, "uDaylight");
    atlasLocation_ = glGetUniformLocation(worldProgram_, "uBlockAtlas");
    useAtlasLocation_ = glGetUniformLocation(worldProgram_, "uUseAtlas");
    if (mvpLocation_ < 0 || lightLocation_ < 0 || daylightLocation_ < 0 ||
        atlasLocation_ < 0 || useAtlasLocation_ < 0) return false;
    glUseProgram(worldProgram_);
    glUniform1i(atlasLocation_, 0);
    glUniform1i(useAtlasLocation_, 1);
    glUseProgram(0);
    return true;
}

bool Engine::UploadBlockAtlas(const std::uint8_t* pixels, std::size_t bytes, int width, int height) {
    if (pixels == nullptr || width <= 0 || height <= 0) return false;
    const std::size_t expected = static_cast<std::size_t>(width) * static_cast<std::size_t>(height) * 4u;
    if (bytes != expected) return false;
    glGenTextures(1, &blockAtlasTexture_);
    if (blockAtlasTexture_ == 0) return false;
    glBindTexture(GL_TEXTURE_2D, blockAtlasTexture_);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    const GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        glDeleteTextures(1, &blockAtlasTexture_);
        blockAtlasTexture_ = 0;
        ENGINE_LOGE("Block atlas upload failed: GL error %d", error);
        return false;
    }
    return true;
}

bool Engine::Initialise(float displayDensity, const std::uint8_t* atlasPixels,
                        std::size_t atlasBytes, int atlasWidth, int atlasHeight) {
    Shutdown();
    ENGINE_LOGI("Starting Minefade Native Engine C++20 / OpenGL ES 3");
    const auto* glVersion = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    const auto* glRenderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
    ENGINE_LOGI("OpenGL version=%s renderer=%s", glVersion != nullptr ? glVersion : "unknown",
                glRenderer != nullptr ? glRenderer : "unknown");

    if (!CreateWorldProgram()) return false;
    if (!UploadBlockAtlas(atlasPixels, atlasBytes, atlasWidth, atlasHeight)) {
        ENGINE_LOGE("Minefade block atlas is missing or invalid");
        return false;
    }
    glGenVertexArrays(1, &worldVao_);
    glGenBuffers(1, &worldVbo_);
    glGenVertexArrays(1, &entityVao_);
    glGenBuffers(1, &entityVbo_);
    glGenVertexArrays(1, &transparentVao_);
    glGenBuffers(1, &transparentVbo_);
    if (worldVao_ == 0 || worldVbo_ == 0 || entityVao_ == 0 || entityVbo_ == 0 ||
        transparentVao_ == 0 || transparentVbo_ == 0) return false;

    if (!storagePath_.empty()) {
        if (!world_.Load(storagePath_, player_.position, inventory_.counts)) {
            world_.GenerateAround(8, 8, 1);
            player_.position = {8.0f, static_cast<float>(world_.GetSurfaceHeight(8, 8)) + 1.05f, 8.0f};
        }
    } else {
        world_.GenerateAround(8, 8, 1);
        player_.position = {8.0f, static_cast<float>(world_.GetSurfaceHeight(8, 8)) + 1.05f, 8.0f};
    }
    world_.GenerateAround(static_cast<int>(std::floor(player_.position.x)),
                          static_cast<int>(std::floor(player_.position.z)), 1);
    lastChunkX_ = static_cast<int>(std::floor(player_.position.x / 16.0f));
    lastChunkZ_ = static_cast<int>(std::floor(player_.position.z / 16.0f));
    entities_.SpawnInitial(world_);
    RebuildWorldMesh();
    UploadWorldMesh();
    UploadTransparentWorldMesh();
    RebuildEntityMesh();
    UploadEntityMesh();

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glDisable(GL_BLEND);
    glViewport(0, 0, width_, height_);

    if (!ui_.Initialise(width_, height_, displayDensity,
                        [this](const std::string& action) { HandleUiAction(action); })) {
        ENGINE_LOGE("RmlUi failed to initialise; game rendering remains available without the HUD");
    }
    lastFrame_ = std::chrono::steady_clock::now();
    lastStats_ = lastFrame_;
    ready_ = true;
    paused_ = false;
    RefreshInventoryUi();
    ENGINE_LOGI("World ready: %zu chunks, %zu vertices", world_.ChunkCount(), worldMesh_.size());
    return true;
}

void Engine::Shutdown() {
    if (ready_) SaveWorld();
    ui_.Shutdown();
    if (worldVbo_ != 0) glDeleteBuffers(1, &worldVbo_);
    if (worldVao_ != 0) glDeleteVertexArrays(1, &worldVao_);
    if (entityVbo_ != 0) glDeleteBuffers(1, &entityVbo_);
    if (entityVao_ != 0) glDeleteVertexArrays(1, &entityVao_);
    if (transparentVbo_ != 0) glDeleteBuffers(1, &transparentVbo_);
    if (transparentVao_ != 0) glDeleteVertexArrays(1, &transparentVao_);
    if (worldProgram_ != 0) glDeleteProgram(worldProgram_);
    if (blockAtlasTexture_ != 0) glDeleteTextures(1, &blockAtlasTexture_);
    worldVbo_ = worldVao_ = entityVbo_ = entityVao_ = transparentVbo_ = transparentVao_ = 0;
    worldProgram_ = blockAtlasTexture_ = 0;
    mvpLocation_ = lightLocation_ = daylightLocation_ = atlasLocation_ = useAtlasLocation_ = -1;
    worldVertexCount_ = transparentVertexCount_ = entityVertexCount_ = 0;
    ready_ = false;
    touches_.clear();
}

void Engine::Resize(int width, int height) {
    width_ = std::max(width, 1);
    height_ = std::max(height, 1);
    glViewport(0, 0, width_, height_);
    ui_.Resize(width_, height_);
}

void Engine::RebuildWorldMesh() {
    world_.BuildMesh(worldMesh_, static_cast<int>(std::floor(player_.position.x)),
                     static_cast<int>(std::floor(player_.position.z)), 1, &transparentWorldMesh_);

    // Alpha blending is order-dependent. Sort transparent triangles from far to near
    // so overlapping water/glass surfaces blend more consistently on mobile GPUs.
    if (transparentWorldMesh_.size() < 6u) return;
    const Vec3 eye = player_.CameraPosition();
    using Triangle = std::array<WorldVertex, 3>;
    std::vector<std::pair<float, Triangle>> sorted;
    sorted.reserve(transparentWorldMesh_.size() / 3u);
    for (std::size_t i = 0; i + 2u < transparentWorldMesh_.size(); i += 3u) {
        Triangle triangle{transparentWorldMesh_[i], transparentWorldMesh_[i + 1u], transparentWorldMesh_[i + 2u]};
        const float cx = (triangle[0].x + triangle[1].x + triangle[2].x) / 3.0f - eye.x;
        const float cy = (triangle[0].y + triangle[1].y + triangle[2].y) / 3.0f - eye.y;
        const float cz = (triangle[0].z + triangle[1].z + triangle[2].z) / 3.0f - eye.z;
        sorted.emplace_back(cx * cx + cy * cy + cz * cz, triangle);
    }
    std::sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) {
        return a.first > b.first;
    });
    std::size_t cursor = 0;
    for (const auto& entry : sorted) {
        for (const WorldVertex& vertex : entry.second) transparentWorldMesh_[cursor++] = vertex;
    }
}

void Engine::UploadWorldMesh() {
    if (worldVao_ == 0 || worldVbo_ == 0) return;
    glBindVertexArray(worldVao_);
    glBindBuffer(GL_ARRAY_BUFFER, worldVbo_);
    glBufferData(GL_ARRAY_BUFFER,
                 static_cast<GLsizeiptr>(worldMesh_.size() * sizeof(WorldVertex)),
                 worldMesh_.empty() ? nullptr : worldMesh_.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, nx)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, r)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, u)));
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    worldVertexCount_ = static_cast<GLsizei>(worldMesh_.size());
}

void Engine::UploadTransparentWorldMesh() {
    if (transparentVao_ == 0 || transparentVbo_ == 0) return;
    glBindVertexArray(transparentVao_);
    glBindBuffer(GL_ARRAY_BUFFER, transparentVbo_);
    glBufferData(GL_ARRAY_BUFFER,
                 static_cast<GLsizeiptr>(transparentWorldMesh_.size() * sizeof(WorldVertex)),
                 transparentWorldMesh_.empty() ? nullptr : transparentWorldMesh_.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, nx)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, r)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, u)));
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    transparentVertexCount_ = static_cast<GLsizei>(transparentWorldMesh_.size());
}

void Engine::RebuildEntityMesh() {
    entityMesh_.clear();
    entities_.AppendMesh(entityMesh_);
}

void Engine::UploadEntityMesh() {
    if (entityVao_ == 0 || entityVbo_ == 0) return;
    glBindVertexArray(entityVao_);
    glBindBuffer(GL_ARRAY_BUFFER, entityVbo_);
    glBufferData(GL_ARRAY_BUFFER,
                 static_cast<GLsizeiptr>(entityMesh_.size() * sizeof(WorldVertex)),
                 entityMesh_.empty() ? nullptr : entityMesh_.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, nx)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, r)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(WorldVertex),
                          reinterpret_cast<const void*>(offsetof(WorldVertex, u)));
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    entityVertexCount_ = static_cast<GLsizei>(entityMesh_.size());
}

double Engine::ElapsedSeconds() const {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

void Engine::Render() {
    if (!ready_) return;
    const auto now = std::chrono::steady_clock::now();
    const float delta = std::chrono::duration<float>(now - lastFrame_).count();
    lastFrame_ = now;
    if (!paused_) {
        environment_.Update(delta);
        player_.Update(world_, delta);
        entities_.Update(world_, delta);
        if (world_.PumpChunkGeneration()) {
            RebuildWorldMesh();
            UploadWorldMesh();
            UploadTransparentWorldMesh();
        }
        RebuildEntityMesh();
        UploadEntityMesh();
        const int playerChunkX = static_cast<int>(std::floor(player_.position.x / 16.0f));
        const int playerChunkZ = static_cast<int>(std::floor(player_.position.z / 16.0f));
        if (playerChunkX != lastChunkX_ || playerChunkZ != lastChunkZ_) {
            world_.RequestGenerateAround(static_cast<int>(std::floor(player_.position.x)),
                                         static_cast<int>(std::floor(player_.position.z)), 1);
            lastChunkX_ = playerChunkX;
            lastChunkZ_ = playerChunkZ;
            RebuildWorldMesh();
            UploadWorldMesh();
            UploadTransparentWorldMesh();
        }
    }
    const auto sky = environment_.SkyColor();
    glClearColor(sky[0], sky[1], sky[2], 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (worldProgram_ != 0 && worldVertexCount_ > 0) {
        const Vec3 eye = player_.CameraPosition();
        const Vec3 forward = player_.Forward();
        const Mat4 projection = Perspective(68.0f * (kPi / 180.0f),
                                            static_cast<float>(width_) / static_cast<float>(height_),
                                            0.08f, 120.0f);
        const Mat4 view = LookAt(eye, Add(eye, forward), {0.0f, 1.0f, 0.0f});
        const Mat4 mvp = Multiply(projection, view);
        const auto sun = environment_.SunDirection();

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glUseProgram(worldProgram_);
        glUniformMatrix4fv(mvpLocation_, 1, GL_FALSE, mvp.v.data());
        glUniform3f(lightLocation_, sun[0], sun[1], sun[2]);
        glUniform1f(daylightLocation_, environment_.Daylight());
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, blockAtlasTexture_);
        glBindVertexArray(worldVao_);
        glDrawArrays(GL_TRIANGLES, 0, worldVertexCount_);
        glBindVertexArray(0);
        glBindTexture(GL_TEXTURE_2D, 0);

        if (entityVertexCount_ > 0) {
            glUniform1i(useAtlasLocation_, 0);
            glBindVertexArray(entityVao_);
            glDrawArrays(GL_TRIANGLES, 0, entityVertexCount_);
            glBindVertexArray(0);
            glUniform1i(useAtlasLocation_, 1);
        }
        if (transparentVertexCount_ > 0) {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(GL_FALSE);
            glBindVertexArray(transparentVao_);
            glDrawArrays(GL_TRIANGLES, 0, transparentVertexCount_);
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }
        glUseProgram(0);
    }

    ++framesSinceStats_;
    if (now - lastStats_ >= std::chrono::seconds(1)) {
        fps_ = static_cast<float>(framesSinceStats_);
        framesSinceStats_ = 0;
        lastStats_ = now;
        char status[128]{};
        std::snprintf(status, sizeof(status), "FPS %.0f · Chunks %zu · Día %.0f%%",
                      fps_, world_.ChunkCount(), environment_.Daylight() * 100.0f);
        ui_.SetStatus(status);
    }

    ui_.UpdateAndRender();
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
}

void Engine::Touch(int action, int pointerId, float x, float y) {
    constexpr int kDown = 0;
    constexpr int kUp = 1;
    constexpr int kMove = 2;
    constexpr int kCancel = 3;
    const bool uiUnhandled = ui_.Touch(action, x, y);

    if (action == kDown) {
        TouchState state;
        state.startX = state.lastX = x;
        state.startY = state.lastY = y;
        state.startedAt = ElapsedSeconds();
        state.uiHandled = !uiUnhandled;
        state.joystick = uiUnhandled && x < static_cast<float>(width_) * 0.42f;
        touches_[pointerId] = state;
        if (state.joystick) player_.SetMovement(0.0f, 0.0f);
        return;
    }

    auto found = touches_.find(pointerId);
    if (found == touches_.end()) return;
    TouchState& state = found->second;
    if (state.uiHandled) {
        if (action == kUp || action == kCancel) touches_.erase(found);
        return;
    }

    if (action == kMove) {
        if (state.joystick) {
            const float dx = (x - state.startX) / 48.0f;
            const float dy = (state.startY - y) / 48.0f;
            state.moved = true;
            player_.SetMovement(dx, dy);
        } else {
            const float deltaX = x - state.lastX;
            const float deltaY = y - state.lastY;
            if (std::abs(x - state.startX) + std::abs(y - state.startY) > 5.0f) state.moved = true;
            player_.Rotate(deltaX, deltaY);
        }
        state.lastX = x;
        state.lastY = y;
    } else if (action == kUp || action == kCancel) {
        if (state.joystick) player_.SetMovement(0.0f, 0.0f);
        else if (action == kUp && !state.moved) {
            if (ElapsedSeconds() - state.startedAt < 0.28) {
                Vec3 broken{};
                BlockId brokenType = BlockId::Air;
                if (world_.BreakRay(player_.CameraPosition(), player_.Forward(), 6.0f, &broken, &brokenType)) {
                    const BlockDefinition* brokenDefinition = GetBlockDefinition(brokenType);
                    const bool hasDrop = brokenDefinition != nullptr &&
                        (brokenDefinition->flags & BlockPlaceable) != 0u && brokenDefinition->dropId > 0u;
                    const bool collected = !hasDrop || inventory_.Add(brokenDefinition->dropId);
                    if (!collected) {
                        world_.SetBlock(static_cast<int>(broken.x), static_cast<int>(broken.y),
                                        static_cast<int>(broken.z), brokenType);
                        ui_.SetStatus("Inventario lleno");
                    } else {
                        RefreshInventoryUi();
                        soundEvents_.fetch_or(1u, std::memory_order_release);
                    }
                }
            } else {
                const std::uint16_t selected = inventory_.SelectedItemId();
                if (selected > 0 && world_.PlaceRay(player_.CameraPosition(), player_.Forward(), 6.0f,
                                                    static_cast<BlockId>(selected))) {
                    inventory_.ConsumeSelected();
                    RefreshInventoryUi();
                    soundEvents_.fetch_or(2u, std::memory_order_release);
                }
            }
            RebuildWorldMesh();
            UploadWorldMesh();
            UploadTransparentWorldMesh();
        }
        touches_.erase(found);
    }
}

void Engine::HandleUiAction(const std::string& action) {
    soundEvents_.fetch_or(4u, std::memory_order_release);
    if (action == "inventory") {
        inventoryVisible_ = !inventoryVisible_;
        if (inventoryVisible_) RefreshInventoryUi();
        ui_.SetPanelVisible("inventory-panel", inventoryVisible_);
        if (inventoryVisible_) {
            ui_.SetPanelVisible("pause-panel", false);
            pauseVisible_ = false;
            paused_ = true;
            player_.SetMovement(0.0f, 0.0f);
        } else {
            paused_ = pauseVisible_;
        }
    } else if (action == "inventory-close") {
        inventoryVisible_ = false;
        ui_.SetPanelVisible("inventory-panel", false);
        paused_ = pauseVisible_;
    } else if (action == "pause") {
        pauseVisible_ = !pauseVisible_;
        paused_ = pauseVisible_;
        if (pauseVisible_) {
            inventoryVisible_ = false;
            ui_.SetPanelVisible("inventory-panel", false);
            player_.SetMovement(0.0f, 0.0f);
        }
        ui_.SetPanelVisible("pause-panel", pauseVisible_);
        paused_ = pauseVisible_ || inventoryVisible_;
    } else if (action == "resume") {
        pauseVisible_ = false;
        paused_ = inventoryVisible_;
        ui_.SetPanelVisible("pause-panel", false);
    } else if (action == "save") {
        SaveWorld();
        ui_.SetStatus("Mundo guardado");
    } else if (action == "save-exit") {
        SaveWorld();
        exitRequested_.store(true, std::memory_order_release);
    } else if (action == "jump") {
        player_.Jump();
    } else if (action.rfind("slot-", 0) == 0 && action.size() == 6) {
        const char digit = action[5];
        if (digit >= '0' && digit <= '8') {
            inventory_.selectedSlot = static_cast<std::uint16_t>(digit - '0');
            RefreshInventoryUi();
        }
    }
}

void Engine::RefreshInventoryUi() {
    std::string markup;
    markup.reserve(1800);
    for (std::size_t i = 0; i < inventory_.counts.size(); ++i) {
        const std::uint32_t encoded = inventory_.counts[i];
        const std::uint16_t itemId = static_cast<std::uint16_t>(encoded / 1000u);
        const std::uint32_t quantity = encoded % 1000u;
        const BlockDefinition* definition = GetBlockDefinition(static_cast<BlockId>(itemId));
        const char* name = definition != nullptr ? definition->nameEs : "Vacío";
        markup += R"(<div class="inventory-row">)";
        markup += std::to_string(i + 1u) + ". " + name;
        if (quantity > 0u) markup += " × " + std::to_string(quantity);
        markup += "</div>";
        std::string label = std::to_string(i + 1u);
        if (quantity > 0u) {
            std::string shortName = name;
            if (shortName.size() > 3u) shortName.resize(3u);
            label += " " + shortName + std::to_string(quantity);
        }
        ui_.SetQuickbarSlot(static_cast<int>(i), label, i == inventory_.selectedSlot);
    }
    ui_.SetInventoryContents(markup);
}

void Engine::SaveWorld() {
    if (storagePath_.empty()) {
        ENGINE_LOGE("Cannot save: Android private storage path has not been supplied");
        return;
    }
    if (!world_.Save(storagePath_, player_.position, inventory_.counts))
        ENGINE_LOGE("Failed to save world to %s", storagePath_.c_str());
    else
        ENGINE_LOGI("World saved to private app storage");
}

void Engine::Pause() {
    if (!ready_) return;
    SaveWorld();
    paused_ = true;
    player_.SetMovement(0.0f, 0.0f);
}

void Engine::Resume() {
    if (!ready_) return;
    paused_ = pauseVisible_ || inventoryVisible_;
}

void Engine::SetStoragePath(std::string path) { storagePath_ = std::move(path) + "/worlds/default.mfworld"; }

bool Engine::ConsumeExitRequest() {
    return exitRequested_.exchange(false, std::memory_order_acq_rel);
}

} // namespace minefade
